<?php
/**
 * Week List View Loop
 * This file sets up the structure for the week list view loop
 *
 */

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if ( !defined('ABSPATH') ) { die('-1'); } ?>

<?php // Show hourly events only ?>
<?php tribe_events_week_set_loop_type( 'hourly' ); ?>

<div class="events-list-view">
	
	<?php while ( tribe_events_week_have_days() ) : tribe_events_week_the_day(); ?>
	<?php if (tribe_events_current_week_day_has_events()) : ?>
	<div id="<?php tribe_events_week_get_the_date(); ?>" class="day-wrapper">
		<?php // Header ?>
		<h2 class="tribe-events-list-separator-day colparent weekparent"><span>+</span> 
			<?php echo get_formatted_date_title(tribe_events_week_get_the_date(false)); ?>
		</h2>
		<div class="col colweek">

      <?php while ( have_posts() ) : the_post(); ?>
		<?php do_action( 'tribe_events_inside_before_loop' ); ?>

		<!-- Event  -->
		<div id="post-<?php the_ID() ?>" class="list-item event">
				<?php tribe_get_template_part( 'week/single', 'event' ) ?>
			</div><!-- .hentry .vevent -->


		<?php do_action( 'tribe_events_inside_after_loop' ); ?>
	<?php endwhile; ?>
        
        
	    </div>
	</div>
	<?php else: ?>
	<div id="<?php tribe_events_week_get_the_date(); ?>" class="day-wrapper">
		<?php // Header ?>
		<h2 class="tribe-events-list-separator-day colparent weekparent"><span>+</span> 
			<?php echo get_formatted_date_title(tribe_events_week_get_the_date(false)); ?>
		</h2>
		<div class="col colweek">
			<p style="margin: -15px 0px 30px 0px;">“Please note there are no organized activities scheduled for today but the parks are open for your enjoyment!” </p>
	    </div>
	</div>

	<?php endif; endwhile; ?>
</div>