<?php
/**
 * Week List View Template
 * The wrapper template for the week list view.
 *
 */

if ( !defined('ABSPATH') ) { die('-1'); } ?>

<?php do_action( 'tribe_events_before_template' ) ?>

<?php // Tribe Bar ?>
<?php tribe_get_template_part( 'modules/bar' ); ?>
<h2 class="weekheader">Daily Programs / Events</h2>

<?php
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. $ends[$number % 10];
}
$sunday = time() - 86400 * intval(date('N'));
$saturday = time() + 86400 * (7 - intval(date('N'))) - 86400;
?>
<div class="week-description">
    For Week Of: <?php echo date('M', $sunday) . ' ' . ordinal(date('j', $sunday)) . ' - ' . ordinal(date('j', $saturday)) ?>
</div>

<?php // Main Events Content ?>
<?php tribe_get_template_part( 'week/content' ) ?>

<?php do_action( 'tribe_events_after_template' ) ?>

	<script type="text/javascript"> 
	jQuery(document).ready(function() { 

		jQuery(".colparent").on( "click", function() {
       		var toggle_switch = jQuery(this).children("span");
		 	jQuery(this).nextUntil('.colparent', '.col').slideToggle('fast', function() {
		 		if (jQuery(this).css('display') == 'none') {
		 			toggle_switch.text('+');
	            } else {
	            	toggle_switch.text('-');
	            }
		 	});
		});

	}); 
	</script>