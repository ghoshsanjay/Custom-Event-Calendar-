<?php
/**
 * Month View Content Template
 * The content template for the month view of events. This template is also used for
 * the response that is returned on month view ajax requests.
 *
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/month/content.php
 *
 * @package TribeEventsCalendar
 *
 */

if ( !defined('ABSPATH') ) { die('-1'); } ?>

<script>
	jQuery(".remove-me").remove();
	jQuery("h1.entry-title").remove();
	jQuery( "<h1 class='entry-title remove-me' itemprop='headline'>Daily Programs & Events</h1>" ).insertAfter( ".breadcrumb" );
	
	jQuery('h1.entry-title:contains("Daily Programs & Events")').text('Calendar');
	jQuery('.breadcrumb').append('<span class="remove-me"> / </span><span class="remove-me">Calendar</span>');
</script>

<div id="tribe-events-content" class="tribe-events-month">

	<!-- Month Title -->
	<?php do_action( 'tribe_events_before_the_title' ) ?>
	
	<?php do_action( 'tribe_events_after_the_title' ) ?>

    <div class="month-description">
        Click on the event pop-up below to be taken to the individual event page for a detailed description of each event, as well as information on time, place, up-to-the-minute status updates regarding cancellations or delays and a link to purchase tickets (if applicable).
    </div>

	<!-- Notices -->
	<?php tribe_events_the_notices() ?>

	<!-- Month Header -->
	<?php do_action( 'tribe_events_before_header' ) ?>
	<div id="tribe-events-header" class="month-header" <?php tribe_events_the_header_attributes() ?>>

		<!-- Header Navigation -->
		<?php tribe_get_template_part( 'month/nav' ); ?>

	</div><!-- #tribe-events-header -->
	<?php do_action( 'tribe_events_after_header' ) ?>

	<!-- Month Grid -->
	<?php tribe_get_template_part( 'month/loop', 'grid' ) ?>

	<!-- Month Footer -->
	<?php do_action( 'tribe_events_before_footer' ) ?>
	<div id="tribe-events-footer">

		<!-- Footer Navigation -->
		<?php do_action( 'tribe_events_before_footer_nav' ); ?>
		<?php tribe_get_template_part( 'month/nav' ); ?>
		<?php do_action( 'tribe_events_after_footer_nav' ); ?>

	</div><!-- #tribe-events-footer -->
	<?php do_action( 'tribe_events_after_footer' ) ?>
	
	<?php tribe_get_template_part( 'month/mobile' ); ?>
	<?php tribe_get_template_part( 'month/tooltip' ); ?>
	
</div><!-- #tribe-events-content -->
