<?php

/**
 *
 * Please see single-event.php in this directory for detailed instructions on how to use and modify these templates.
 *
 */

?>

<script type="text/html" id="tribe_tmpl_tooltip">
	<div id="tribe-events-tooltip-[[=eventId]]" class="tribe-events-tooltip">
		[[ if(imageTooltipSrc.length) { ]]
		<div class="tribe-events-event-thumb">
			<img src="[[=imageTooltipSrc]]" alt="[[=title]]" />
		</div>
		[[ } ]]
		<div class="tribe-events-event-body">	
			<h4 class="entry-title summary">[[=raw title]]</h4>
			[[ if(excerpt.length) { ]]
			<div class="entry-summary description">[[=raw excerpt]]</div>
			[[ } ]]
			<a href="[[=permalink]]"><div class="blackbar">Full Info & Tickets<i class="fa fa-chevron-right pull-right"></i></div></a>
			<div class="tribe-events-arrow-right"></div>
		</div>
	</div>
</script>