<?php
/**
 * Single Event Template
 * A single event. This displays the event title, description, meta, and
 * optionally, the Google map for the event.
 * 
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/single-event.php
 *
 * @package TribeEventsCalendar
 *
 */

if ( !defined('ABSPATH') ) { die('-1'); }

$event_id = get_the_ID();

?>
<script>
	jQuery("h1.entry-title").remove();
	jQuery( "<h1 class='entry-title tribetitle' itemprop='headline'>Event Info</h1>" ).insertAfter( ".breadcrumb" );
	jQuery(".breadcrumb").html(jQuery(".breadcrumb").html().replace("Events", "<a href='/events/photo/?tribeHideRecurrence=1'>Events</a>"));
</script>

<div id="tribe-events-content" class="tribe-events-single vevent hentry">

	

	

	<?php while ( have_posts() ) :  the_post(); ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<!-- Event featured image, but exclude link -->
			<?php echo tribe_event_featured_image($event_id, 'full', false); ?>

			<!-- Notices -->
			<?php tribe_events_the_notices() ?>

			<?php the_title( '<h2 class="tribe-events-single-event-title summary entry-title">', '</h2>' ); ?>



			<div class="tribe-events-schedule updated published tribe-clearfix">
				<div>STATUS: <span class="eventsinglestatus"><?php echo tribe_get_custom_field('Status'); ?></span></div>
				<div>WHERE: <span><?php echo tribe_get_venue( $event_id, false); ?></span></div>
				<div class="when">WHEN: <span><?php echo tribe_events_event_schedule_details( $event_id, '<span>', '</span>'); ?></span></div>
				<div>TICKETING INFORMATION: <span>
					
					<?php  if ( tribe_get_cost() ) :  ?>
						<span class=""><?php echo tribe_get_cost( null, true ) ?> </span>
					<?php else : ?>
						This event is free	
					<?php endif; ?> </span>
					<?php if(tribe_get_custom_field('EventBrite Ticket URL') <> '') {  ?>
						<a href="<?php echo tribe_get_custom_field('EventBrite Ticket URL'); ?>" class="yellow-dwnld" target="_blank" style="margin-left:10px;">Purchase Tickets</a>
					<?php } ?>
				</div>
			</div>

			<!-- Event meta -->
			<?php//do_action( 'tribe_events_single_event_before_the_meta' ) ?>
			<?php //do_action( 'tribe_events_single_event_after_the_meta' ) ?>


			<!-- Event content -->
			<h5 class="eventdetailheader">Event Details</h5>
			<?php do_action( 'tribe_events_single_event_before_the_content' ) ?>
			<div class="tribe-events-single-event-description tribe-events-content entry-content description">
				<?php the_content(); ?>
			</div><!-- .tribe-events-single-event-description -->
			

			<!-- Event meta -->
			
			</div> <!-- #post-x -->
		<?php if( get_post_type() == TribeEvents::POSTTYPE && tribe_get_option( 'showComments', false ) ) comments_template() ?>
	<?php endwhile; ?>


	<!-- Event footer -->
    <div id="tribe-events-footer">
		<!-- Navigation -->
		<!-- Navigation -->
		<h3 class="tribe-events-visuallyhidden"><?php _e( 'Event Navigation', 'tribe-events-calendar' ) ?></h3>
		<!-- INSERT SOCIAL SHARE HERE -->
	</div><!-- #tribe-events-footer -->

</div><!-- #tribe-events-content -->
