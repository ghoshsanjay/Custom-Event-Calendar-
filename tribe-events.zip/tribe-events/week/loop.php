<?php
/**
 * Week List View Loop
 * This file sets up the structure for the week list view loop
 *
 */

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if ( !defined('ABSPATH') ) { die('-1'); } ?>

<?php // Show hourly events only ?>
<?php tribe_events_week_set_loop_type( 'hours' ); ?>

<div class="events-list-view">
	
	<?php while ( tribe_events_week_have_days() ) : tribe_events_week_the_day(); ?>
	<?php if (tribe_events_current_week_day_has_events()) : ?>
	<div id="<?php tribe_events_week_get_the_date(); ?>" class="day-wrapper">
		<?php // Header ?>
		<h2 class="tribe-events-list-separator-day colparent weekparent"><span>+</span> 
			<?php echo get_formatted_date_title(tribe_events_week_get_the_date(false)); ?>
		</h2>
		<div class="col colweek">

					<div title="<?php tribe_events_week_get_the_date(); ?>" class="tribe-events-mobile-day column <?php tribe_events_week_column_classes(); ?>">
						<?php
						$day = tribe_events_week_get_current_day();

						foreach ( $day['hourly_events'] as $event ) : ?>
							<?php tribe_get_template_part( 'pro/week/single-event', 'hourly', array( 'event' => $event ) ); ?>
						<?php endforeach; ?>

					</div><!-- hourly column -->

	    </div>
	</div>
	<?php else: ?>
	<div id="<?php tribe_events_week_get_the_date(); ?>" class="day-wrapper">
		<?php // Header ?>
		<h2 class="tribe-events-list-separator-day colparent weekparent"><span>+</span> 
			<?php echo get_formatted_date_title(tribe_events_week_get_the_date(false)); ?>
		</h2>
		<div class="col colweek">
			<p style="margin: -15px 0px 30px 0px;">“Please note there are no organized activities scheduled for today but the parks are open for your enjoyment!” </p>
	    </div>
	</div>

	<?php endif; endwhile; ?>
</div>